- Preheat oven to 150C.
- For the Caramel, lightly grease six 9cm diameter x 2cm deep tartlet tins. Place the sugar and water into a saucepan then cook over high until sugar starts to caramelise. Swirl the pan until sugar has melted evenly and forms a dark caramel.
- Remove from heat and pour caramel evenly into tins. Set aside in a deep baking dish.
- For the Custard, place egg yolks, egg and sugar into a saucepan and mix well to combine. Add the milk, cream and vanilla and whisk until smooth. Place over medium heat and stir with a silicone spatula until mixture reaches 80C. Remove from the heat. Pour mixture through a fine sieve into a jug then pour into the tartlet tins.
- Pour boiling water into baking dish until halfway up the side of the tins. Carefully transfer to the oven and bake until set but still slightly wobbly in the centres, about 45 minutes. Remove from the oven and allow to cool slightly.
- Transfer tins onto a tray and place into the fridge to set. Invert into shallow bowls to serve.

![](/Users/vishnupriya/Desktop/Honey's Driver/Whitehat Jr/Git Projects/c26-v2-MasterchefJunior/caramel.jpg)